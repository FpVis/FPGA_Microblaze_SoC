/*
 * button.c
 *
 *  Created on: 2025. 3. 10.
 *      Author: kccistc
 */

#include "dht11.h"

void dht11_Init(dht11_Typedef *dht11){
	dht11->enable = 0X01;
}

uint32_t dht11_test(dht11_Typedef *dht11){
	return dht11->test_number;
}

uint32_t dht11_read_state(dht11_Typedef *dht11){
	return dht11->result_state;
}

uint32_t dht11_read_temp(dht11_Typedef *dht11){
	return dht11->temperature;
}

uint32_t dht11_read_hum(dht11_Typedef *dht11){
	return dht11->humidity;
}

uint32_t dht11_read_checksum(dht11_Typedef *dht11){
	return dht11->checksum;
}
