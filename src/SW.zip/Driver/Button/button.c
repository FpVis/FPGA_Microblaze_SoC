
#include "button.h"
#include "sleep.h"


void Button_Init(btnHandler *hBtn, GPIO_TypeDef *GPIOx, uint32_t pos)
{
	hBtn->GPIOx = GPIOx;
	hBtn->pos = pos;
	hBtn->GPIOx->DDR &= ~(1<<pos);
	hBtn->prevState = RELEASED;
}

uint32_t Button_GetState(btnHandler *hBtn)
{
	uint32_t curState = GPIO_Read(hBtn->GPIOx) & 1<<hBtn->pos;

	if (hBtn->prevState == RELEASED && curState != RELEASED) {
		usleep(10000);
		hBtn->prevState = PUSHED;
		return ACT_PUSH;
	}
	else if (hBtn->prevState != RELEASED && curState == RELEASED) {
		usleep(10000);
		hBtn->prevState = RELEASED;
		return ACT_RELEASE;
	}
	return NO_ACT;
}
