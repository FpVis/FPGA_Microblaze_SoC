
#ifndef DRIVER_BUTTON_BUTTON_H_
#define DRIVER_BUTTON_BUTTON_H_

#include "../GPIO/gpio.h"

enum {RELEASED, PUSHED};
enum {NO_ACT, ACT_PUSH, ACT_RELEASE};

typedef struct {
	GPIO_TypeDef *GPIOx;
	uint32_t pos;
	uint32_t prevState;
}btnHandler;

void Button_Init(btnHandler *hBtn, GPIO_TypeDef *GPIOx, uint32_t pos);
uint32_t Button_GetState(btnHandler *hBtn);

#endif /* DRIVER_BUTTON_BUTTON_H_ */
