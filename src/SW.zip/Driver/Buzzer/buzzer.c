/*
 * buzzer.c
 *
 *  Created on: 2025. 3. 14.
 *      Author: kccistc
 */
#include "buzzer.h"

void BuzzerBasicSetUp(Buzzer_TypeDef * bz)
{
	bz->PSC = 1000; // prescale 100khz
}

void BuzzerSetUp(Buzzer_TypeDef * bz, uint32_t hz)
{
	bz->ARR = 100000/hz; // prescale 100khz
}

void BuzzerOn(Buzzer_TypeDef * bz)
{
	bz->BCR |= (1<<EN_BIT);
}

void BuzzerOff(Buzzer_TypeDef * bz)
{
	bz->BCR &= ~(1<<EN_BIT);
}

uint32_t ReadBuzzerState(Buzzer_TypeDef * bz)
{
	return bz->BCR;
}
