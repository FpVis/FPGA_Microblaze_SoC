/*
 * buzzer.h
 *
 *  Created on: 2025. 3. 14.
 *      Author: kccistc
 */

#ifndef DRIVER_BUZZER_BUZZER_H_
#define DRIVER_BUZZER_BUZZER_H_

#include <stdint.h>
#include "xparameters.h"

typedef struct {
	volatile uint32_t BCR;
	volatile uint32_t PSC;
	volatile uint32_t ARR;
}Buzzer_TypeDef;

#define BUZZER_BASE_ADDR			XPAR_BUZZER_0_S00_AXI_BASEADDR
#define BUZZER0						(Buzzer_TypeDef *)(BUZZER_BASE_ADDR)

//#define C4							262
//#define D4							294
//#define E4							330
//#define F4							349
//#define G4							392
//#define A4							440
//#define B4							494
//#define C5							523

enum
{
C4 = 262, // ��
D4 = 294, // ��
E4 = 330, // ��
F4 = 349, // ��
G4 = 392, // ��
A4 = 440, // ��
B4 = 494, // ��
C5 = 523  // ��
};

#define EN_BIT						0
#define SYS_CLK						100000000

void BuzzerBasicSetUp(Buzzer_TypeDef * bz);
void BuzzerSetUp(Buzzer_TypeDef * bz, uint32_t hz);
void BuzzerOn(Buzzer_TypeDef * bz);
void BuzzerOff(Buzzer_TypeDef * bz);
uint32_t ReadBuzzerState(Buzzer_TypeDef * bz);

#endif /* DRIVER_BUZZER_BUZZER_H_ */
