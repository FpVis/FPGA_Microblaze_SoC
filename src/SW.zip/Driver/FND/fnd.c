/*
 * fnd.c
 *
 *  Created on: 2025. 3. 12.
 *      Author: kccistc
 */

#include "fnd.h"

void Fnd_DisplayOn(FND_TypeDef *fnd)
{
	fnd -> FCR = 0x01;
}

void Fnd_DisplayOff(FND_TypeDef *fnd)
{
	fnd -> FCR = 0x00;
}

void Fnd_WriteData(FND_TypeDef *fnd, uint32_t data)
{
	uint32_t temp;
	temp = data;
	if(temp > 9999)	temp = 9999;
	fnd->FDR = temp;
}

void Fnd_WriteDot(FND_TypeDef *fnd, uint32_t dot)
{
	uint32_t temp;
	temp = dot;
	fnd->FDPR = ~(temp & 0x0f);
}

uint32_t Fnd_ReadData(FND_TypeDef *fnd)
{
	return fnd -> FDR;
}

uint32_t Fnd_ReadDot(FND_TypeDef *fnd)
{
	return ~fnd -> FDPR & 0x0f;
}
