/*
 * fnd.h
 *
 *  Created on: 2025. 3. 12.
 *      Author: kccistc
 */

#ifndef DRIVER_FND_FND_H_
#define DRIVER_FND_FND_H_

#include <stdint.h>
#include "xparameters.h"

typedef struct {
	volatile uint32_t FCR;
	volatile uint32_t FDR;
	volatile uint32_t FDPR;
}FND_TypeDef;

#define FND_BASE_ADDR	XPAR_FNDCONTROLLER_0_S00_AXI_BASEADDR
//#define FCR				*(volatile uint32_t *)(FND_BASE_ADDR + 0x00)
//#define FDR				*(volatile uint32_t *)(FND_BASE_ADDR + 0x04)
//#define FDPR			*(volatile uint32_t *)(FND_BASE_ADDR + 0x08)

#define FND				(FND_TypeDef *)(FND_BASE_ADDR)

void Fnd_DisplayOn(FND_TypeDef *fnd);
void Fnd_DisplayOff(FND_TypeDef *fnd);
void Fnd_WriteData(FND_TypeDef *fnd, uint32_t data);
void Fnd_WriteDot(FND_TypeDef *fnd, uint32_t dot);
uint32_t Fnd_ReadData(FND_TypeDef *fnd);
uint32_t Fnd_ReadDot(FND_TypeDef *fnd);

#endif /* DRIVER_FND_FND_H_ */
