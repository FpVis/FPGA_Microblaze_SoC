#include "gpio.h"

void GPIO_SetDataDirection(GPIO_TypeDef *GPIOx, uint32_t dir)
{
	GPIOx->DDR = dir;
}

void GPIO_Write(GPIO_TypeDef *GPIOx, uint32_t data)
{
	GPIOx->ODR = data;
}

uint32_t GPIO_GetData(GPIO_TypeDef *GPIOx)
{
	return GPIOx->ODR;
}

uint32_t GPIO_Read(GPIO_TypeDef *GPIOx)
{
	return GPIOx->IDR;
}

void GPIO_Toggle(GPIO_TypeDef *GPIOx, uint32_t tog)
{
	GPIOx->ODR ^= tog;
}
