/*
 * gpio.h
 *
 *  Created on: 2025. 3. 10.
 *      Author: kccistc
 */

#ifndef DRIVER_GPIO_GPIO_H_
#define DRIVER_GPIO_GPIO_H_

#include "xparameters.h"
#include <stdint.h>

typedef struct {
	uint32_t DDR;
	uint32_t ODR;
	uint32_t IDR;
} GPIO_TypeDef;

#define GPIOA_BASE_ADDR		XPAR_GPIO_0_S00_AXI_BASEADDR
#define GPIOB_BASE_ADDR		XPAR_GPIO_1_S00_AXI_BASEADDR

#define GPIOA (GPIO_TypeDef *)(GPIOA_BASE_ADDR)
#define GPIOB (GPIO_TypeDef *)(GPIOB_BASE_ADDR)

void GPIO_SetDataDirection(GPIO_TypeDef *GPIOx, uint32_t dir);
void GPIO_Write(GPIO_TypeDef *GPIOx, uint32_t data);
uint32_t GPIO_Read(GPIO_TypeDef *GPIOx);
void GPIO_Toggle(GPIO_TypeDef *GPIOx, uint32_t tog);
uint32_t GPIO_GetData(GPIO_TypeDef *GPIOx);


#endif /* DRIVER_GPIO_GPIO_H_ */
