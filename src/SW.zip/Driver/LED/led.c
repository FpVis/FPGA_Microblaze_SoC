#include "led.h"

void LED_Init(GPIO_TypeDef *GPIOx)
{
	GPIOx->DDR = 0xff;
}

void Led_On(GPIO_TypeDef *GPIOx, uint32_t pos)
{
	uint32_t temp;
	temp = GPIO_GetData(GPIOx);
	GPIO_Write(GPIOx, temp | 1 << pos);
}

void Led_Off(GPIO_TypeDef *GPIOx, uint32_t pos)
{
	uint32_t temp;
	temp = GPIO_GetData(GPIOx);
	GPIO_Write(GPIOx, temp & ~(1 << pos));
}

void led_Toggle(GPIO_TypeDef *GPIOx, uint32_t pos)
{
	uint32_t temp;
	temp = GPIO_GetData(GPIOx);
	GPIO_Write(GPIOx, temp ^ (1 << pos));
}

void Led_OnAll(GPIO_TypeDef *GPIOx)
{
	GPIO_Write(GPIOx, 0xff);
}

void Led_OffAll(GPIO_TypeDef *GPIOx)
{
	GPIO_Write(GPIOx, 0x00);
}

void LED_Write(GPIO_TypeDef *GPIOx, uint32_t data)
{
	GPIO_Write(GPIOx, data);
}
