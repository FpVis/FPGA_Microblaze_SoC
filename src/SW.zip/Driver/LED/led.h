/*
 * led.h
 *
 *  Created on: 2025. 3. 10.
 *      Author: kccistc
 */

#ifndef DRIVER_LED_LED_H_
#define DRIVER_LED_LED_H_

#include "../GPIO/gpio.h" // .. -> back folder

void LED_Init(GPIO_TypeDef *GPIOx);
void Led_On(GPIO_TypeDef *GPIOx, uint32_t pos);
void Led_Off(GPIO_TypeDef *GPIOx, uint32_t pos);
void led_Toggle(GPIO_TypeDef *GPIOx, uint32_t pos);
void Led_OnAll(GPIO_TypeDef *GPIOx);
void Led_OffAll(GPIO_TypeDef *GPIOx);
void LED_Write(GPIO_TypeDef *GPIOx, uint32_t data);

#endif /* DRIVER_LED_LED_H_ */
