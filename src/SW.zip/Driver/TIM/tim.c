/*
 * tim.c
 *
 *  Created on: 2025. 3. 12.
 *      Author: kccistc
 */

#include "tim.h"

void TIM_Start (TIM_TypeDef * tim)
{
	tim->TCR |= (1<<EN_BIT);
}

void TIM_Stop (TIM_TypeDef * tim)
{
	tim->TCR &= ~(1<<EN_BIT);
}

void TIM_SetPrescaler(TIM_TypeDef * tim, uint32_t value)
{
	tim->PSC = value;
}

uint32_t TIM_GetPrescaler(TIM_TypeDef * tim)
{
	return tim->PSC;
}

void TIM_SetReload(TIM_TypeDef * tim, uint32_t value)
{
	tim->ARR = value;
}

uint32_t TIM_GetReload(TIM_TypeDef * tim)
{
	return tim->ARR;
}

uint32_t TIM_GetTCNT(TIM_TypeDef * tim)
{
	return tim->TCNT;
}

void TIM_Clear(TIM_TypeDef * tim)
{
	tim->PSC |= (1<<CLEAR_BIT);
}
