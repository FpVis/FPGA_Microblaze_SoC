/*
 * tim.h
 *
 *  Created on: 2025. 3. 12.
 *      Author: kccistc
 */

#ifndef DRIVER_TIM_TIM_H_
#define DRIVER_TIM_TIM_H_

#include "xparameters.h"
#include <stdint.h>

typedef struct{
	volatile uint32_t TCR;
	volatile uint32_t PSC;
	volatile uint32_t TCNT;
	volatile uint32_t ARR;
} TIM_TypeDef;

#define EN_BIT					0
#define CLEAR_BIT				1

#define TIM_BASE_ADDR			XPAR_TIMER_INTERUPT_0_S00_AXI_BASEADDR

#define TIM0					(TIM_TypeDef *)(TIM_BASE_ADDR)

void TIM_Start (TIM_TypeDef * tim);
void TIM_Stop (TIM_TypeDef * tim);
void TIM_SetPrescaler(TIM_TypeDef * tim, uint32_t value);
uint32_t TIM_GetPrescaler(TIM_TypeDef * tim);
void TIM_SetReload(TIM_TypeDef * tim, uint32_t value);
uint32_t TIM_GetReload(TIM_TypeDef * tim);
uint32_t TIM_GetTCNT(TIM_TypeDef * tim);
void TIM_Clear(TIM_TypeDef * tim);

#endif /* DRIVER_TIM_TIM_H_ */
