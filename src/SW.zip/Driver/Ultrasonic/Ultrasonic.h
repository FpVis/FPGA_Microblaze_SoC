// Ultrasonic.h

#ifndef DRIVER_ULTRASONIC_ULTRASONIC_H_
#define DRIVER_ULTRASONIC_ULTRASONIC_H_

#include <stdint.h>
#include "xparameters.h"

typedef struct
{
	volatile uint32_t UCR;
	volatile uint32_t USR;
	volatile uint32_t UDR;
} Ultrasonic_TypeDef;

#define ULTRA_START_Bit 0
#define ULTRA_DONE_Bit 0
#define ULTRA_ERROR_Bit 1

#define ULTRASONIC_BASE_ADDR XPAR_ULTRASONIC_0_S00_AXI_BASEADDR
#define ULTRASONIC0 (Ultrasonic_TypeDef *)(ULTRASONIC_BASE_ADDR)

void ULTRA_Init();
void ULTRA_Start(Ultrasonic_TypeDef *ultra);
void ULTRA_Stop(Ultrasonic_TypeDef *ultra);
uint32_t ULTRA_GetDone(Ultrasonic_TypeDef *ultra);
uint32_t ULTRA_GetError(Ultrasonic_TypeDef *ultra);
uint32_t ULTRA_GetDistance(Ultrasonic_TypeDef *ultra);

#endif /* DRIVER_ULTRASONIC_ULTRASONIC_H_ */
