// ultrasonic.c

#include "Ultrasonic.h"

void ULTRA_Init()
{
	ULTRA_Start(ULTRASONIC0);
}
void ULTRA_Start(Ultrasonic_TypeDef *ultra)
{
	ultra->UCR |= (1 << ULTRA_START_Bit);
}
void ULTRA_Stop(Ultrasonic_TypeDef *ultra)
{
	ultra->UCR |= (0 << ULTRA_START_Bit);
}
uint32_t ULTRA_GetDone(Ultrasonic_TypeDef *ultra)
{
	return (ultra->USR & (1 << ULTRA_DONE_Bit));
}
uint32_t ULTRA_GetError(Ultrasonic_TypeDef *ultra)
{
	return (ultra->USR & (1 << ULTRA_ERROR_Bit)) >> ULTRA_ERROR_Bit;
}
uint32_t ULTRA_GetDistance(Ultrasonic_TypeDef *ultra)
{
	return ultra->UDR;
}
