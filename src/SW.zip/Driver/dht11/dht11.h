
#include "xparameters.h"
#include <stdint.h>

#define DHT11_BASE_ADDR XPAR_DHT11_0_S00_AXI_BASEADDR
#define DHT11A (dht11_Typedef *)(DHT11_BASE_ADDR)

typedef struct{
	uint32_t enable;
	uint32_t result_state;
	uint32_t humidity;
	uint32_t temperature;
	uint32_t checksum;
}dht11_Typedef;

void dht11_Init(dht11_Typedef *dht11);
uint32_t dht11_read_state(dht11_Typedef *dht11);
uint32_t dht11_read_temp(dht11_Typedef *dht11);
uint32_t dht11_read_hum(dht11_Typedef *dht11);
uint32_t dht11_read_checksum(dht11_Typedef *dht11);
