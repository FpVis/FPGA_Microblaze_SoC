/*
 * controller.c
 *
 *  Created on: 2025. 3. 13.
 *      Author: kccistc
 */

#include "controller.h"

XIntc intc; // interrupt

moduleState_e moduleState;
stopWatchState_e stopWatchState;
clkState_e clkState;
ultraSonic_e ultraSonicState;
dht11_e dht11State;
state_TypeDef state;

stopwatch_TypeDef stopWatchData;
clock_TypeDef ClockData;
dht11_TypeDef dht11Data;
uint32_t dis;

presentData_TypeDef present;

uint32_t bz_flag;
uint32_t bz_count =0;
uint32_t listenEvent;

//uint32_t Three_Bare[] = {E4,D4,C4,D4,E4,E4,E4,D4,D4,D4,E4,E4,E4,E4,D4,C4,D4,E4,E4,E4,D4,D4,E4,D4,C4};

void Controller_UpdataInData(ListenerData_TypeDef listenData)
{
	if(listenData.btnID == BTN_UP)
	{
		listenEvent = BTN_UP;
		bz_flag = 1;
	}
	else if (listenData.btnID == BTN_MODE)
	{
		listenEvent = BTN_MODE;
	}
	else if (listenData.btnID == BTN_RUNSTOP)
	{
		listenEvent = BTN_RUNSTOP;
	}
	else if (listenData.btnID == BTN_DOWN)
	{
		listenEvent = BTN_DOWN;
		bz_flag = 1;
	}
}

void Controller_CLK_SW_DHT_US_FSM()
{
	switch(moduleState)
	{
	case STOPWATCH :
		if (listenEvent == BTN_MODE) {
			moduleState = CLK;
			clkState = C_CLK;
		}

		switch(stopWatchState)
			{
			case S_IDLE :
				break;
			case S_STOP :
				if (listenEvent == BTN_RUNSTOP) stopWatchState = S_RUN;
				else if (listenEvent == BTN_DOWN) stopWatchState = S_CLEAR;
				break;
			case S_RUN :
				if (listenEvent == BTN_RUNSTOP) stopWatchState = S_STOP;
				else if (listenEvent == BTN_DOWN) stopWatchState = S_CLEAR;
				break;
			case S_CLEAR :
				TIM_Clear(TIM0);
				stopWatchData.msec=0;
				stopWatchData.sec = 0;
				stopWatchData.min = 0;
				stopWatchData.hour = 0;
				stopWatchState = S_STOP;
				break;
			}
		break;

	case CLK :
		if (listenEvent == BTN_MODE) {
			moduleState = DHT11;
			dht11State = D_TEMP;
		}

		switch(clkState)
		{
		case C_IDLE :
			break;
		case C_CLK :
			if (listenEvent == BTN_RUNSTOP) clkState = C_HOURCHANGE;
			break;
		case C_HOURCHANGE :
			if (listenEvent == BTN_RUNSTOP) clkState = C_MINCHANGE;
			if (listenEvent == BTN_UP) ClockData.hour++;
			else if (listenEvent == BTN_DOWN)
			{
				ClockData.hour--;
				if(ClockData.hour < 0) ClockData.hour = 23;
			}
			break;
		case C_MINCHANGE :
			if (listenEvent == BTN_RUNSTOP) clkState = C_CLK;
			if (listenEvent == BTN_UP) ClockData.min++;
			else if (listenEvent == BTN_DOWN)
			{
				ClockData.min--;
				if(ClockData.min < 0) ClockData.min = 59;
			}
			break;
		}
		break;


	case DHT11 :
		if (listenEvent == BTN_MODE) {
			moduleState = ULTRASONIC;
			ultraSonicState = U_STOP;
		}

		switch(dht11State)
		{
		case D_IDLE :
			break;
		case D_TEMP :
			if (listenEvent == BTN_RUNSTOP) dht11State = D_HUMID;
			break;
		case D_HUMID :
			if (listenEvent == BTN_RUNSTOP) dht11State = D_TEMP;
			break;
		}
		break;


	case ULTRASONIC :
		if (listenEvent == BTN_MODE) {
			moduleState = STOPWATCH;
			stopWatchState = S_STOP;
		}

		switch(ultraSonicState)
		{
		case U_IDLE :
			break;
		case U_STOP :
			if (listenEvent == BTN_RUNSTOP) ultraSonicState = U_RUN;
			break;
		case U_RUN :
			if (listenEvent == BTN_RUNSTOP) ultraSonicState = U_STOP;
			break;
		}
		break;
	}

	//buzzer
	if (bz_flag)
		{
			BuzzerOn(BUZZER0);
			BuzzerSetUp(BUZZER0, 4000);
			if (bz_count > 1000) {
				bz_count = 0;
				bz_flag = 0;
			}
		}
	else if (bz_flag == 0)
		{
			BuzzerOff(BUZZER0);
			BuzzerSetUp(BUZZER0, 0);
		}
	//

	listenEvent = 0;
	state.moduleState = moduleState;
	state.stopwatchState = stopWatchState;
	state.clkState = clkState;
	state.dht11State = dht11State;
	state.ultrasonicState = ultraSonicState;

	present.SW = stopWatchData;
	present.CLK = ClockData;
	present.DHT = dht11Data;
	present.dis = dis;
	present.presentState = state;
	Presenter_Updata(present);

}

void timerIntrHandler()
{
	bz_count++;

	//stop watch
	if (stopWatchState == S_RUN)
	{
		stopWatchData.msec++;

		if(stopWatchData.msec == 1000){
			stopWatchData.msec=0;
			stopWatchData.sec++;
		}

		if(stopWatchData.sec == 60){
			stopWatchData.sec = 0;
			stopWatchData.min++;
		}

		if(stopWatchData.min == 60){
			stopWatchData.min = 0;
			stopWatchData.hour++;
		}

		if(stopWatchData.hour == 24){
			stopWatchData.hour = 0;
		}
	}

	// clk
		ClockData.msec++;

		if(ClockData.msec == 1000){
			ClockData.msec=0;
			ClockData.sec ++;

		}

		if(ClockData.sec == 60){
			ClockData.sec = 0;
			ClockData.min++;
		}

		if(ClockData.min == 60){
			ClockData.min = 0;
			ClockData.hour++;
		}

		if(ClockData.hour == 24){
			ClockData.hour = 0;
		}


	// dht11
	if (dht11State == D_TEMP)
	{
		dht11Data.temp = dht11_read_temp(DHT11A);
	}
	else if (dht11State == D_HUMID)
	{
		dht11Data.humid = dht11_read_hum(DHT11A);
	}

	// ultrasonic
	if (ultraSonicState ==U_RUN)
	{
		ULTRA_Start(ULTRASONIC0);
		dis = ULTRA_GetDistance(ULTRASONIC0);
	}
	else if (ultraSonicState ==U_STOP)
	{
		ULTRA_Stop(ULTRASONIC0);
	}
}

void intc_init()
{
	// hardware info setting
	XIntc_Initialize(&intc, XPAR_INTC_0_DEVICE_ID);

	// Exception, interrupt setting
	Xil_ExceptionInit();
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT, (Xil_ExceptionHandler) XIntc_InterruptHandler, &intc);
	Xil_ExceptionEnable();

	//	Interrupt ISR Funtion
	XIntc_Connect(&intc, XPAR_INTC_0_TIMER_INTERUPT_0_VEC_ID, (Xil_ExceptionHandler) timerIntrHandler, 0);

	//	Interrupt Enable
	XIntc_Enable(&intc, XPAR_INTC_0_TIMER_INTERUPT_0_VEC_ID);

	//	Interrupt Start
	XIntc_Start(&intc, XIN_REAL_MODE);
}

void TIM0_Init()
{
    TIM_SetPrescaler(TIM0, 100-1);
    TIM_SetReload(TIM0, 1000-1);
    TIM_Clear(TIM0);
    TIM_Start(TIM0);
}

void Controller_Init()
{
	intc_init();
	TIM0_Init();
	dht11_Init(DHT11A);
	ULTRA_Init();
	BuzzerOff(BUZZER0);
	BuzzerBasicSetUp(BUZZER0);

	stopWatchState = S_STOP;
	clkState = C_IDLE;
	dht11State = D_IDLE;
	ultraSonicState = U_IDLE;
	moduleState = STOPWATCH;

	stopWatchData.hour = 0;
	stopWatchData.min = 0;
	stopWatchData.sec = 0;
	stopWatchData.msec = 0;

	ClockData.hour = 0;
	ClockData.min = 0;
	ClockData.sec = 0;
	ClockData.msec = 0;

	dht11Data.humid = 0;
	dht11Data.temp = 0;

	dis = 0;
}
