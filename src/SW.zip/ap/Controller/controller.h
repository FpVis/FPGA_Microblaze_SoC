/*
 * controller.h
 *
 *  Created on: 2025. 3. 13.
 *      Author: kccistc
 */

#ifndef AP_CONTROLLER_CONTROLLER_H_
#define AP_CONTROLLER_CONTROLLER_H_

#include "xintc.h"
#include "xil_exception.h"
#include "xil_printf.h"

#include "../../Driver/TIM/tim.h"
#include "../../Driver/Button/button.h"
#include "../../Driver/Buzzer/buzzer.h"
#include "../../Driver/dht11/dht11.h"
#include "../../Driver/Ultrasonic/Ultrasonic.h"
#include "../Presenter/presenter.h"
#include "../Listener/listener.h"
#include "../Model/model.h"

void Controller_UpdataInData(ListenerData_TypeDef listenData);
void Controller_CLK_SW_DHT_US_FSM();
void Controller_StopWatchFSM();
void Controller_CLK_FSM();
void Controller_DHT11_FSM();
void Controller_US_FSM();
void timerIntrHandler();
void timerIntrHandler2();
void intc_init();
void TIM0_Init();
void Controller_Init();

#endif /* AP_CONTROLLER_CONTROLLER_H_ */
