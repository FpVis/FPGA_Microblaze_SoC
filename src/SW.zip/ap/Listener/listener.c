/*
 * listener.c
 *
 *  Created on: 2025. 3. 13.
 *      Author: kccistc
 */
#include "listener.h"

btnHandler hBtnUp; // bz / time up
btnHandler hBtnMode; // mode change
btnHandler hBtnRunStop; //runstop / time change
btnHandler hBtnDown; // clear / time down

void Listener_Init()
{
    Button_Init(&hBtnUp, GPIOB, 0);	// 0: up, 1: left, 2: right, 3: down
    Button_Init(&hBtnMode, GPIOB, 1);
    Button_Init(&hBtnRunStop, GPIOB, 2);
    Button_Init(&hBtnDown, GPIOB, 3);
}

void Listener_ButtonCheck()
{
	static uint32_t prevTime = 0;
	uint32_t curTime;
	curTime = TickTimer_GetTick();

	if (curTime -prevTime <100) return;
	prevTime = curTime;

	int btnState;
	ListenerData_TypeDef listenData;

	btnState = Button_GetState(&hBtnUp);
	if (btnState == ACT_PUSH)
	{
		listenData.btnID = BTN_UP;
		listenData.btnState = btnState;
		Controller_UpdataInData(listenData);
	}

	btnState = Button_GetState(&hBtnMode);
	if (btnState == ACT_PUSH)
	{
		listenData.btnID = BTN_MODE;
		listenData.btnState = btnState;
		Controller_UpdataInData(listenData);
	}

	btnState = Button_GetState(&hBtnRunStop);
	if (btnState == ACT_PUSH)
	{
		listenData.btnID = BTN_RUNSTOP;
		listenData.btnState = btnState;
		Controller_UpdataInData(listenData);
	}

	btnState = Button_GetState(&hBtnDown);
	if (btnState == ACT_PUSH)
	{
		listenData.btnID = BTN_DOWN;
		listenData.btnState = btnState;
		Controller_UpdataInData(listenData);
	}
}
