/*
 * listener.h
 *
 *  Created on: 2025. 3. 13.
 *      Author: kccistc
 */

#ifndef AP_LISTENER_LISTENER_H_
#define AP_LISTENER_LISTENER_H_

#include <stdint.h>
#include "../../Driver/Button/button.h"
#include "../../Driver/GPIO/gpio.h"
#include "../../Driver/Buzzer/buzzer.h"
#include "../../common/TickTimer/ticktimer.h"
#include "../Controller/controller.h"
#include "../Presenter/presenter.h"
#include "../Model/model.h"
#include "sleep.h"

void Listener_Init();
void Listener_ButtonCheck();

#endif /* AP_LISTENER_LISTENER_H_ */
