/*
 * model.h
 *
 *  Created on: 2025. 3. 13.
 *      Author: kccistc
 */

#ifndef AP_MODEL_MODEL_H_
#define AP_MODEL_MODEL_H_

typedef struct {
	uint32_t btnID;
	uint32_t btnState;
}ListenerData_TypeDef;

enum {BTN_UP=10, BTN_MODE, BTN_RUNSTOP, BTN_DOWN};

typedef struct{
	uint32_t msec;
	uint32_t sec;
	uint32_t min;
	uint32_t hour;
} stopwatch_TypeDef;

typedef struct{
	uint32_t msec;
	uint32_t sec;
	int min;
	int hour;
} clock_TypeDef;

typedef struct{
	uint32_t temp;
	uint32_t humid;
} dht11_TypeDef;

typedef struct{
	uint32_t moduleState;
	uint32_t stopwatchState;
	uint32_t clkState;
	uint32_t dht11State;
	uint32_t ultrasonicState;
} state_TypeDef;

typedef struct{
	stopwatch_TypeDef SW;
	clock_TypeDef CLK;
	dht11_TypeDef DHT;
	uint32_t dis;
	state_TypeDef presentState;
} presentData_TypeDef;

typedef enum {S_IDLE, S_STOP, S_RUN, S_CLEAR} stopWatchState_e;
typedef enum {C_IDLE=4, C_CLK, C_HOURCHANGE, C_MINCHANGE} clkState_e;
typedef enum {U_IDLE=8, U_STOP, U_RUN} ultraSonic_e;
typedef enum {D_IDLE=11, D_TEMP, D_HUMID} dht11_e;
typedef enum {STOPWATCH, CLK, DHT11, ULTRASONIC} moduleState_e;

#endif /* AP_MODEL_MODEL_H_ */
