/*
 * presenter.c
 *
 *  Created on: 2025. 3. 13.
 *      Author: kccistc
 */

#include "presenter.h"

stopwatch_TypeDef presentSWData;
clock_TypeDef	presentCLKData;
dht11_TypeDef presentdhtData;
presentData_TypeDef presentAll;

state_TypeDef presentMode;
uint32_t present_dis;

void Presenter_Init()
{
    LED_Init(GPIOA);
	Fnd_DisplayOn(FND);
}

void Presenter_Updata(presentData_TypeDef presentData)
{
	presentSWData = presentData.SW;
	presentCLKData = presentData.CLK;
	presentdhtData = presentData.DHT;
	present_dis = presentData.dis;
	presentMode = presentData.presentState;

	presentAll.SW = presentSWData;
	presentAll.CLK = presentCLKData;
	presentAll.DHT = presentdhtData;
	presentAll.dis = present_dis;
	presentAll.presentState = presentMode;
}

void Presenter_Display()
{
		//led
		Presenter_UpdateLED(presentMode);
		//fnd
		Presenter_UpdataFND(presentAll);
		//uart
		Presenter_UpdataUART(presentAll);
}


void Presenter_UpdateLED(state_TypeDef mode)
{
	switch(mode.moduleState)
	{
	case STOPWATCH :
		switch(mode.stopwatchState)
		{
		case S_STOP:
			Led_On(GPIOA, 0);
			Led_Off(GPIOA, 1);
			Led_Off(GPIOA, 2);
			Led_Off(GPIOA, 3);
			Led_Off(GPIOA, 4);
			Led_Off(GPIOA, 5);
			Led_Off(GPIOA, 6);
			Led_Off(GPIOA, 7);
			break;
		case S_RUN:
			Led_Off(GPIOA, 0);
			Led_On(GPIOA, 1);
			Led_Off(GPIOA, 2);
			Led_Off(GPIOA, 3);
			Led_Off(GPIOA, 4);
			Led_Off(GPIOA, 5);
			Led_Off(GPIOA, 6);
			Led_Off(GPIOA, 7);
			break;
		}
	break;


	case CLK :
		switch(mode.clkState)
		{
		case C_CLK:
			Led_Off(GPIOA, 0);
			Led_Off(GPIOA, 1);
			Led_On(GPIOA, 2);
			Led_Off(GPIOA, 3);
			Led_Off(GPIOA, 4);
			Led_Off(GPIOA, 5);
			Led_Off(GPIOA, 6);
			Led_Off(GPIOA, 7);
			break;
		case C_HOURCHANGE:
			Led_Off(GPIOA, 0);
			Led_Off(GPIOA, 1);
			Led_Off(GPIOA, 2);
			Led_On(GPIOA, 3);
			Led_Off(GPIOA, 4);
			Led_Off(GPIOA, 5);
			Led_Off(GPIOA, 6);
			Led_Off(GPIOA, 7);
			break;
		case C_MINCHANGE:
			Led_Off(GPIOA, 0);
			Led_Off(GPIOA, 1);
			Led_Off(GPIOA, 2);
			Led_Off(GPIOA, 3);
			Led_On(GPIOA, 4);
			Led_Off(GPIOA, 5);
			Led_Off(GPIOA, 6);
			Led_Off(GPIOA, 7);
			break;
		}
	break;


	case ULTRASONIC :
		switch(mode.ultrasonicState)
		{
		case U_RUN :
			Led_Off(GPIOA, 0);
			Led_Off(GPIOA, 1);
			Led_Off(GPIOA, 2);
			Led_Off(GPIOA, 3);
			Led_Off(GPIOA, 4);
			Led_On(GPIOA, 5);
			Led_Off(GPIOA, 6);
			Led_Off(GPIOA, 7);
			break;
		}
	break;


	case DHT11 :
		switch(mode.dht11State)
		{
		case D_TEMP :
			Led_Off(GPIOA, 0);
			Led_Off(GPIOA, 1);
			Led_Off(GPIOA, 2);
			Led_Off(GPIOA, 3);
			Led_Off(GPIOA, 4);
			Led_Off(GPIOA, 5);
			Led_On(GPIOA, 6);
			Led_Off(GPIOA, 7);
			break;
		case D_HUMID :
			Led_Off(GPIOA, 0);
			Led_Off(GPIOA, 1);
			Led_Off(GPIOA, 2);
			Led_Off(GPIOA, 3);
			Led_Off(GPIOA, 4);
			Led_Off(GPIOA, 5);
			Led_Off(GPIOA, 6);
			Led_On(GPIOA, 7);
			break;
		}
	break;
	}
}

void Presenter_UpdataFND(presentData_TypeDef presentData)
{
	switch(presentData.presentState.moduleState)
	{
		case STOPWATCH :
			switch(presentData.presentState.stopwatchState)
			{
				case S_RUN:
					Fnd_WriteData(FND, presentData.SW.sec*100 + presentData.SW.msec/10);
					break;
				case S_STOP:
					Fnd_WriteData(FND, presentData.SW.sec*100 + presentData.SW.msec/10);
					break;
				case S_CLEAR:
					Fnd_WriteData(FND, presentData.SW.sec*100 + presentData.SW.msec/10);
					break;
			}
			break;

		case CLK :
			switch(presentData.presentState.clkState)
			{
				case C_CLK:
					Fnd_WriteData(FND, presentData.CLK.hour*100 + presentData.CLK.min);
					break;
				case C_HOURCHANGE:
					Fnd_WriteData(FND, presentData.CLK.hour*100 + presentData.CLK.min);
					break;
				case C_MINCHANGE:
					Fnd_WriteData(FND, presentData.CLK.hour*100 + presentData.CLK.min);
					break;
			}
			break;

		case ULTRASONIC :
			switch(presentData.presentState.ultrasonicState)
			{
				case U_RUN:
					Fnd_WriteData(FND, presentData.dis);
					break;
				case U_STOP:
					Fnd_WriteData(FND, presentData.dis);
					break;
			}
			break;

		case DHT11 :
			switch(presentData.presentState.dht11State)
			{
				case D_TEMP:
					Fnd_WriteData(FND, presentData.DHT.temp);
					break;
				case D_HUMID:
					Fnd_WriteData(FND, presentData.DHT.humid);
					break;
			}
			break;
	}

	if(presentData.CLK.msec <500) Fnd_WriteDot(FND, 0x04);
	else Fnd_WriteDot(FND, 0x00);
}

void Presenter_UpdataUART(presentData_TypeDef presentData)
{
	static int prevTime = 0;
	int curTime = TickTimer_GetTick();

	if(curTime - prevTime < 100) return;
	prevTime = curTime;

	switch(presentData.presentState.moduleState)
		{
			case STOPWATCH :
				switch(presentData.presentState.stopwatchState)
				{
					case S_RUN:
						xil_printf(" [S_RUN]   : %02d:%02d:%02d:%02d\n", presentData.SW.hour,presentData.SW.min,presentData.SW.sec,presentData.SW.msec);
						break;
					case S_STOP:
						xil_printf(" [S_STOP]  : %02d:%02d:%02d:%02d\n", presentData.SW.hour,presentData.SW.min,presentData.SW.sec,presentData.SW.msec);
						break;
					case S_CLEAR:
						xil_printf(" [S_CLEAR] : %02d:%02d:%02d:%02d\n", presentData.SW.hour,presentData.SW.min,presentData.SW.sec,presentData.SW.msec);
						break;
				}
				break;

			case CLK :
				switch(presentData.presentState.clkState)
				{
					case C_CLK:
						xil_printf(" [C_CLOCK] : %02d:%02d:%02d:%02d\n", presentData.CLK.hour,presentData.CLK.min,presentData.CLK.sec,presentData.CLK.msec);
						break;
					case C_HOURCHANGE:
						xil_printf(" [C_HOURCHANGE] : %02d:%02d:%02d:%02d\n", presentData.CLK.hour,presentData.CLK.min,presentData.CLK.sec,presentData.CLK.msec);
						break;
					case C_MINCHANGE:
						xil_printf(" [C_MINCHANGE] : %02d:%02d:%02d:%02d\n", presentData.CLK.hour,presentData.CLK.min,presentData.CLK.sec,presentData.CLK.msec);
						break;
				}
				break;

			case ULTRASONIC :
				switch(presentData.presentState.ultrasonicState)
				{
					case U_RUN:
						xil_printf(" [U_RUN] : %d\n", presentData.dis);
						break;
					case U_STOP:
						xil_printf(" [U_STOP] : %d\n", presentData.dis);
						break;
				}
				break;

			case DHT11 :
				switch(presentData.presentState.dht11State)
				{
					case D_TEMP:
						xil_printf(" [D_TEMP] : %d\n", presentData.DHT.temp);
						break;
					case D_HUMID:
						xil_printf(" [D_HUMID] : %d\n", presentData.DHT.humid);
						break;
				}
				break;
		}
}
