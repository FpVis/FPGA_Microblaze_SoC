/*
 * presenter.h
 *
 *  Created on: 2025. 3. 13.
 *      Author: kccistc
 */

#ifndef AP_PRESENTER_PRESENTER_H_
#define AP_PRESENTER_PRESENTER_H_

#include <stdint.h>
#include "xil_printf.h"
#include "../../Driver/LED/led.h"
#include "../../Driver/FND/fnd.h"
#include "../../Driver/GPIO/gpio.h"
#include "../../Driver/Buzzer/buzzer.h"
#include "../../common/TickTimer/ticktimer.h"
#include "../Model/model.h"
#include "../Controller/controller.h"

void Presenter_Init();
void Presenter_Updata(presentData_TypeDef presentData);
void Presenter_Display();
void Presenter_UpdateLED(state_TypeDef mode);
void Presenter_UpdataFND(presentData_TypeDef presentData);
void Presenter_UpdataUART(presentData_TypeDef presentData);

#endif /* AP_PRESENTER_PRESENTER_H_ */
