/*
 * ap.c
 *
 *  Created on: 2025. 3. 10.
 *      Author: kccistc
 */

#include "apMain.h"

void apMain()
{
    while(1)
    {
    	Listener_ButtonCheck();
    	Controller_CLK_SW_DHT_US_FSM();
    	//Controller_StopWatchFSM();
    	//Controller_CLK_FSM();
    	//Controller_DHT11_FSM();
    	//Controller_US_FSM();
    	Presenter_Display();
    }
}

void apInit()
{
	Listener_Init();
	Controller_Init();
	Presenter_Init();

    TickTimer_Init();
}

