/*
 * apMain.h
 *
 *  Created on: 2025. 3. 10.
 *      Author: kccistc
 */

#ifndef AP_APMAIN_H_
#define AP_APMAIN_H_

#include "Controller/controller.h"
#include "Presenter/presenter.h"
#include "Listener/listener.h"

void apMain();

void FSM_ContextSwitch();
void apInit();
void timerIntrHandler();
void intc_init();
enum {ALL_ON, LEFT, RIGHT, ALL_OFF};

//enum {IDLE, STOP, START, CLEAR};

#endif /* AP_APMAIN_H_ */
