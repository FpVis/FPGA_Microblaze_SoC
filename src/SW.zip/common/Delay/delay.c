/*
 * delay.c
 *
 *  Created on: 2025. 3. 11.
 *      Author: kccistc
 */
#include "delay.h"

void delay_ms(uint32_t msec)
{
	uint32_t curTime, prevTime;

	curTime = TickTimer_GetTick();
	prevTime = curTime;

	while (curTime - prevTime < msec) {
		curTime = TickTimer_GetTick();
	}
}
