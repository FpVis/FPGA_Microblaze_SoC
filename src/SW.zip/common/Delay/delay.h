/*
 * delay.h
 *
 *  Created on: 2025. 3. 11.
 *      Author: kccistc
 */

#ifndef COMMON_DELAY_DELAY_H_
#define COMMON_DELAY_DELAY_H_

#include "../TickTimer/ticktimer.h"

void delay_ms(uint32_t msec);

#endif /* COMMON_DELAY_DELAY_H_ */
