/*
 * ticktimer.c
 *
 *  Created on: 2025. 3. 11.
 *      Author: kccistc
 */

#include "../../common/TickTimer/ticktimer.h"

tickTimer_TypeDef * tick;

void TickTimer_Init()
{
	tick= TICK_TIMER;
	TickTimer_Clear();
	TickTimer_SetPSC(100000-1);
	TickTimer_Enable();
}

void TickTimer_Clear()
{
	tick->TCR |= TMR_CLEAR_BIT;
}

void TickTimer_Enable()
{
	tick->TCR |= TMR_ENABLE_BIT;
}

void TickTimer_Stop()
{
	tick->TCR &= ~TMR_ENABLE_BIT;
}

uint32_t TickTimer_GetTick()
{
	return tick->TCNT;
}

void TickTimer_SetPSC(uint32_t prescale)
{
	tick->PSC = prescale;
}
