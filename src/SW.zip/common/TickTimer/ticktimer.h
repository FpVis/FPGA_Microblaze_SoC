/*
 * ticktimer.h
 *
 *  Created on: 2025. 3. 11.
 *      Author: kccistc
 */

#ifndef COMMON_TICKTIMER_TICKTIMER_H_
#define COMMON_TICKTIMER_TICKTIMER_H_

#include "xparameters.h"
#include <stdint.h>

typedef struct {
	volatile uint32_t TCR;
	volatile uint32_t PSC;
	volatile uint32_t TCNT;
} tickTimer_TypeDef;

#define TMR_ENABLE_BIT		(1<<0)
#define TMR_CLEAR_BIT		(1<<1)

#define TICK_TIMER_BASE_ADDR XPAR_BASICTIMER_0_S00_AXI_BASEADDR

#define TICK_TIMER_TCR	 	(TICK_TIMER_BASE_ADDR + 0x00)
#define TICK_TIMER_PSC	 	(TICK_TIMER_BASE_ADDR + 0x04)
#define TICK_TIMER_TCNT 	(TICK_TIMER_BASE_ADDR + 0x08)

#define TICK_TIMER			(tickTimer_TypeDef *)(TICK_TIMER_BASE_ADDR)

void TickTimer_Init();
void TickTimer_Clear();
void TickTimer_Enable();
void TickTimer_Stop();
uint32_t TickTimer_GetTick();
void TickTimer_SetPSC(uint32_t prescale);

#endif /* COMMON_TICKTIMER_TICKTIMER_H_ */
